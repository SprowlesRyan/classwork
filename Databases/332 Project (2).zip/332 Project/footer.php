<?php

$mysqli->close();

?>
