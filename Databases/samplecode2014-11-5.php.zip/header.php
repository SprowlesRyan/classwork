<?php
$mysqli = new mysqli('localhost', 'csci332user', 'snow123', 'csci332');
if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') '  . $mysqli->connect_error);
}
?>